import { MainLayout } from "@/components/layout/MainLayout";
import { NoteEditor } from "@/components/NoteEditor";

export default function NotesPage() {
  return (
    <MainLayout>
      <NoteEditor />
    </MainLayout>
  );
}

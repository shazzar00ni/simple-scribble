import { useEffect, useState } from "react";
import { useNotesStore } from "@/lib/store";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { format } from "date-fns";
import { Separator } from "./ui/separator";

export function NoteEditor() {
  const { notes, activeNoteId, updateNote } = useNotesStore();
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  
  const activeNote = notes.find((note) => note.id === activeNoteId);
  
  useEffect(() => {
    if (activeNote) {
      setTitle(activeNote.title);
      setContent(activeNote.content);
    } else {
      setTitle("");
      setContent("");
    }
  }, [activeNote]);
  
  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTitle(e.target.value);
    if (activeNoteId) {
      updateNote(activeNoteId, { title: e.target.value });
    }
  };
  
  const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setContent(e.target.value);
    if (activeNoteId) {
      updateNote(activeNoteId, { content: e.target.value });
    }
  };
  
  if (!activeNote) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-6 text-center text-muted-foreground">
        <p>No note selected</p>
        <p className="text-sm">Select a note from the sidebar or create a new one</p>
      </div>
    );
  }
  
  return (
    <div className="flex flex-col h-full p-4 gap-4">
      <div className="flex justify-between items-center">
        <Input
          value={title}
          onChange={handleTitleChange}
          className="text-xl font-semibold border-none h-auto p-0 focus-visible:ring-0"
          placeholder="Note title"
        />
        <span className="text-xs text-muted-foreground">
          {format(new Date(activeNote.updatedAt), "MMM d, yyyy h:mm a")}
        </span>
      </div>
      <Separator />
      <Textarea
        value={content}
        onChange={handleContentChange}
        placeholder="Write your note here..."
        className="flex-1 resize-none border-none focus-visible:ring-0 text-base"
      />
    </div>
  );
}
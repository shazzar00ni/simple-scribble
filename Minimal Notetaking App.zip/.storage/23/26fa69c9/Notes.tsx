import { MainLayout } from "@/components/layout/MainLayout";
import { NoteEditor } from "@/components/NoteEditor";
import { Header } from "@/components/layout/Header";

export default function NotesPage() {
  return (
    <div className="flex flex-col h-screen">
      <Header />
      <div className="flex-1 overflow-hidden">
        <MainLayout>
          <NoteEditor />
        </MainLayout>
      </div>
    </div>
  );
}
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Note } from '@/types';

interface NotesState {
  notes: Note[];
  activeNoteId: string | null;
  addNote: (note: Omit<Note, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateNote: (id: string, updates: Partial<Omit<Note, 'id' | 'createdAt' | 'updatedAt'>>) => void;
  deleteNote: (id: string) => void;
  setActiveNoteId: (id: string | null) => void;
}

export const useNotesStore = create<NotesState>()(
  persist(
    (set) => ({
      notes: [],
      activeNoteId: null,
      addNote: (note) => {
        const now = new Date();
        const newNote: Note = {
          id: crypto.randomUUID(),
          ...note,
          createdAt: now,
          updatedAt: now,
        };
        
        set((state) => ({
          notes: [newNote, ...state.notes],
          activeNoteId: newNote.id,
        }));
      },
      updateNote: (id, updates) => {
        set((state) => ({
          notes: state.notes.map((note) =>
            note.id === id
              ? { ...note, ...updates, updatedAt: new Date() }
              : note
          ),
        }));
      },
      deleteNote: (id) => {
        set((state) => ({
          notes: state.notes.filter((note) => note.id !== id),
          activeNoteId: state.activeNoteId === id ? null : state.activeNoteId,
        }));
      },
      setActiveNoteId: (id) => {
        set({ activeNoteId: id });
      },
    }),
    {
      name: 'notes-storage',
    }
  )
);
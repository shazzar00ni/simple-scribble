import { Header } from "@/components/layout/Header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Check, Edit3, Feather, Leaf, Zap, Lock, StickyNote } from "lucide-react";
import { Link } from "react-router-dom";

export default function LandingPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      {/* Hero Section */}
      <section className="py-20 md:py-28 bg-gradient-to-r from-primary/10 to-secondary/10">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl">
                Simple Scribble
              </h1>
              <p className="mx-auto max-w-[700px] text-lg text-muted-foreground md:text-xl">
                Effortless note-taking for minimalists. Focus on your thoughts, not the interface.
              </p>
            </div>
            <div className="space-x-4">
              <Link to="/notes">
                <Button size="lg" className="animate-pulse">Start Writing Now</Button>
              </Link>
              <Link to="#features">
                <Button variant="outline" size="lg">Learn More</Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Section */}
      <section className="py-16 md:py-24" id="features">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                Features
              </h2>
              <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Everything you need to capture your thoughts, nothing you don't.
              </p>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
            <Card className="border-primary/20 dark:border-primary/30">
              <CardHeader className="pb-2">
                <Feather className="h-10 w-10 mb-2 text-primary" />
                <CardTitle>Distraction-Free Writing</CardTitle>
                <CardDescription>
                  Clean interface that lets you focus on your thoughts.
                </CardDescription>
              </CardHeader>
            </Card>
            <Card className="border-primary/20 dark:border-primary/30">
              <CardHeader className="pb-2">
                <Zap className="h-10 w-10 mb-2 text-primary" />
                <CardTitle>Real-time Saving</CardTitle>
                <CardDescription>
                  Your notes are saved automatically as you type.
                </CardDescription>
              </CardHeader>
            </Card>
            <Card className="border-primary/20 dark:border-primary/30">
              <CardHeader className="pb-2">
                <Leaf className="h-10 w-10 mb-2 text-primary" />
                <CardTitle>Lightweight &amp; Fast</CardTitle>
                <CardDescription>
                  Minimal design means maximum performance.
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-16 md:py-24 bg-muted/50" id="pricing">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                Simple Pricing
              </h2>
              <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Choose the plan that works for you.
              </p>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
            {/* Free Plan */}
            <Card className="flex flex-col justify-between border-primary/20">
              <CardHeader>
                <CardTitle>Free</CardTitle>
                <div className="mt-4 text-4xl font-bold">$0</div>
                <CardDescription className="mt-2">Perfect for casual note-takers</CardDescription>
              </CardHeader>
              <CardContent className="flex-grow">
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center">
                    <Check className="mr-2 h-4 w-4 text-primary" /> Up to 50 notes
                  </li>
                  <li className="flex items-center">
                    <Check className="mr-2 h-4 w-4 text-primary" /> Basic formatting
                  </li>
                  <li className="flex items-center">
                    <Check className="mr-2 h-4 w-4 text-primary" /> Local storage
                  </li>
                </ul>
              </CardContent>
              <div className="p-6 pt-0">
                <Link to="/notes">
                  <Button className="w-full" variant="outline">Get Started</Button>
                </Link>
              </div>
            </Card>
            
            {/* Pro Plan */}
            <Card className="flex flex-col justify-between relative border-2 border-primary">
              <div className="absolute top-0 right-0 transform translate-x-2 -translate-y-2 bg-primary text-primary-foreground text-xs py-1 px-3 rounded-full">
                Popular
              </div>
              <CardHeader>
                <CardTitle>Pro</CardTitle>
                <div className="mt-4 text-4xl font-bold">$5<span className="text-lg font-normal">/mo</span></div>
                <CardDescription className="mt-2">For serious note enthusiasts</CardDescription>
              </CardHeader>
              <CardContent className="flex-grow">
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center">
                    <Check className="mr-2 h-4 w-4 text-primary" /> Unlimited notes
                  </li>
                  <li className="flex items-center">
                    <Check className="mr-2 h-4 w-4 text-primary" /> Cloud sync across devices
                  </li>
                  <li className="flex items-center">
                    <Check className="mr-2 h-4 w-4 text-primary" /> Advanced formatting
                  </li>
                  <li className="flex items-center">
                    <Check className="mr-2 h-4 w-4 text-primary" /> Categories and tags
                  </li>
                </ul>
              </CardContent>
              <div className="p-6 pt-0">
                <Link to="/notes">
                  <Button className="w-full">Upgrade to Pro</Button>
                </Link>
              </div>
            </Card>
            
            {/* Business Plan */}
            <Card className="flex flex-col justify-between border-primary/20">
              <CardHeader>
                <CardTitle>Business</CardTitle>
                <div className="mt-4 text-4xl font-bold">$12<span className="text-lg font-normal">/mo</span></div>
                <CardDescription className="mt-2">For teams and professionals</CardDescription>
              </CardHeader>
              <CardContent className="flex-grow">
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center">
                    <Check className="mr-2 h-4 w-4 text-primary" /> Everything in Pro
                  </li>
                  <li className="flex items-center">
                    <Check className="mr-2 h-4 w-4 text-primary" /> Team collaboration
                  </li>
                  <li className="flex items-center">
                    <Check className="mr-2 h-4 w-4 text-primary" /> Version history
                  </li>
                  <li className="flex items-center">
                    <Check className="mr-2 h-4 w-4 text-primary" /> Advanced security
                  </li>
                  <li className="flex items-center">
                    <Check className="mr-2 h-4 w-4 text-primary" /> Priority support
                  </li>
                </ul>
              </CardContent>
              <div className="p-6 pt-0">
                <Link to="/notes">
                  <Button className="w-full" variant="outline">Contact Sales</Button>
                </Link>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-8 md:py-12 mt-auto">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
            <div className="flex items-center gap-2">
              <StickyNote className="h-5 w-5" />
              <p className="text-sm">© 2025 Simple Scribble. All rights reserved.</p>
            </div>
            <div className="flex gap-4">
              <Link to="#" className="text-sm underline-offset-4 hover:underline">Terms</Link>
              <Link to="#" className="text-sm underline-offset-4 hover:underline">Privacy</Link>
              <Link to="#" className="text-sm underline-offset-4 hover:underline">Contact</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
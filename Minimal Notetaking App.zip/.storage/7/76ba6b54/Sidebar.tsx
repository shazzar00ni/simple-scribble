import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useNotesStore } from "@/lib/store";
import { PlusCircle, Trash2 } from "lucide-react";
import { format } from "date-fns";

export function Sidebar() {
  const { notes, activeNoteId, addNote, setActiveNoteId, deleteNote } = useNotesStore();
  
  const handleCreateNote = () => {
    addNote({
      title: "New Note",
      content: "",
    });
  };
  
  return (
    <div className="flex h-full flex-col bg-background border-r">
      <div className="p-4 flex items-center justify-between">
        <h2 className="text-lg font-semibold">My Notes</h2>
        <Button variant="ghost" size="icon" onClick={handleCreateNote}>
          <PlusCircle className="h-5 w-5" />
          <span className="sr-only">Add note</span>
        </Button>
      </div>
      <Separator />
      {notes.length === 0 ? (
        <div className="flex flex-col items-center justify-center flex-1 p-4 text-center text-muted-foreground">
          <p>No notes yet</p>
          <p className="text-sm">Create a new note to get started</p>
          <Button onClick={handleCreateNote} variant="outline" className="mt-4">
            <PlusCircle className="h-4 w-4 mr-2" />
            New Note
          </Button>
        </div>
      ) : (
        <ScrollArea className="flex-1">
          <div className="p-2 space-y-1">
            {notes.map((note) => (
              <div
                key={note.id}
                className={cn(
                  "flex items-start justify-between group p-3 rounded-md cursor-pointer hover:bg-accent",
                  activeNoteId === note.id ? "bg-accent" : ""
                )}
                onClick={() => setActiveNoteId(note.id)}
              >
                <div className="flex flex-col flex-1 min-w-0">
                  <span className="text-sm font-medium truncate">{note.title}</span>
                  <span className="text-xs text-muted-foreground truncate">
                    {format(new Date(note.updatedAt), "MMM d, yyyy")}
                  </span>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="opacity-0 group-hover:opacity-100"
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteNote(note.id);
                  }}
                >
                  <Trash2 className="h-4 w-4" />
                  <span className="sr-only">Delete note</span>
                </Button>
              </div>
            ))}
          </div>
        </ScrollArea>
      )}
    </div>
  );
}
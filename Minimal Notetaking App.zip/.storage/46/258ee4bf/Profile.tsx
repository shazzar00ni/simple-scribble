import { useEffect, useState } from "react";
import { useAuth } from "@/components/auth/AuthProvider";
import { supabase, TABLES, Profile as ProfileType } from "@/lib/supabase";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Loader2, Check } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

const profileSchema = z.object({
  display_name: z.string().min(2, { message: "Name must be at least 2 characters" }).max(50),
  bio: z.string().max(160).optional(),
});

type ProfileFormValues = z.infer<typeof profileSchema>;

export default function Profile() {
  const { user, profile: authProfile } = useAuth();
  const [loading, setLoading] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      display_name: authProfile?.display_name || "",
      bio: authProfile?.bio || "",
    },
  });

  // Update form values when profile loads
  useEffect(() => {
    if (authProfile) {
      form.reset({
        display_name: authProfile.display_name || "",
        bio: authProfile.bio || "",
      });
    }
  }, [authProfile, form]);

  const onSubmit = async (data: ProfileFormValues) => {
    if (!user) return;
    
    try {
      setLoading(true);
      setSaveSuccess(false);
      
      const { error } = await supabase
        .from(TABLES.PROFILES)
        .update({
          display_name: data.display_name,
          bio: data.bio,
          updated_at: new Date().toISOString(),
        })
        .eq('id', user.id);
      
      if (error) throw error;
      
      setSaveSuccess(true);
      toast.success("Profile updated successfully");
      
      // Reset success indicator after a delay
      setTimeout(() => setSaveSuccess(false), 2000);
      
    } catch (error: any) {
      toast.error("Failed to update profile");
      console.error("Error updating profile:", error.message);
    } finally {
      setLoading(false);
    }
  };

  const userInitials = user?.email ? user.email.substring(0, 2).toUpperCase() : "??";

  return (
    <div className="container max-w-4xl py-10">
      <h1 className="text-2xl font-bold mb-6">Your Profile</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-[1fr_3fr] gap-6">
        {/* Profile Summary Card */}
        <Card>
          <CardHeader className="text-center">
            <div className="flex justify-center mb-2">
              <Avatar className="h-24 w-24">
                <AvatarImage src={authProfile?.avatar_url || ""} alt={authProfile?.display_name || "User"} />
                <AvatarFallback className="text-lg">{userInitials}</AvatarFallback>
              </Avatar>
            </div>
            <CardTitle>{authProfile?.display_name || "User"}</CardTitle>
            <CardDescription className="line-clamp-3">{authProfile?.bio || "No bio provided yet"}</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">Email: {user?.email}</p>
          </CardContent>
        </Card>
        
        {/* Edit Profile Form */}
        <Card>
          <CardHeader>
            <CardTitle>Edit Profile</CardTitle>
            <CardDescription>Update your profile information</CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="display_name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Display Name</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Your name"
                          {...field}
                          disabled={loading}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="bio"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Bio</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Tell us about yourself"
                          className="resize-none"
                          {...field}
                          disabled={loading}
                          value={field.value || ""}
                        />
                      </FormControl>
                      <FormDescription>
                        Write a short bio about yourself. Max 160 characters.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Button type="submit" disabled={loading || saveSuccess}>
                  {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {saveSuccess && <Check className="mr-2 h-4 w-4" />}
                  {loading ? "Saving..." : saveSuccess ? "Saved" : "Save Changes"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
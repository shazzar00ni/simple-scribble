import { RegisterForm } from "@/components/auth/RegisterForm";
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/lib/supabase";

export default function Register() {
  const navigate = useNavigate();
  
  // Check if user is already logged in and redirect if they are
  useEffect(() => {
    const checkSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        navigate("/notes");
      }
    };
    
    checkSession();
  }, [navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="w-full max-w-md">
        <RegisterForm />
      </div>
    </div>
  );
}